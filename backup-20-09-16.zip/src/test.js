
$('.save-html').click(function() {
    /* var findArray = ["\<!--", "\-->"];
    var replaceArray = ["<", ">"];

    var html = $('#quine').html();

    for (var k = 0; k < findArray.length; k++) {
        html.replace(findArray[k],replaceArray[k]);
        console.log(html);
    }*/

    alert("hellO");

    $('#quine').html("html");
});